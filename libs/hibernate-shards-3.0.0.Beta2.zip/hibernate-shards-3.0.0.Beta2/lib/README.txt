Hibernate Shards dependencies
=============================

Core
====
hibernate3.jar: required
hibernate core dependencies: required (see Hibernate Core for more information)
#list all other dependencies (including version) and put the jar in ./lib

Test
====
#If needed list test dependencies